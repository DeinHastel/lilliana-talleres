def calcular(X, n):
    resultado = X * n
    return resultado

# profe para ahorrar tiempo pondre variables fijas en vez de inputs

X = 2.5  
n = 3    

resultado = calcular(X, n)
print(f"{X}^{n} = {resultado}")



