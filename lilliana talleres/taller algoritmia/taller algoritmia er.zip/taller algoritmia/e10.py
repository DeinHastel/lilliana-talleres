def valor_absoluto(numero):
    return abs(numero)

numero = -5 

resultado = valor_absoluto(numero)
print(f"El valor absoluto de {numero} es {resultado}")