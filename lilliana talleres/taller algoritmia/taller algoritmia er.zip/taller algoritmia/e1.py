def media(x,y,z):
    sum = x+y+z
    
    return sum / 3

x = int(input("primer numero"))
y = int(input("segundo numero"))
z = int(input("tercer numero"))

med = media(z,y,z)

print(med)