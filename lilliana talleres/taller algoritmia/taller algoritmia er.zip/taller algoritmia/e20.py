def convertir_a_mayusculas(cadena):
    return cadena.upper()

def convertir_a_minusculas(cadena):
    return cadena.lower()

cadena = "Hola Mundo"

cadena_mayusculas = convertir_a_mayusculas(cadena)
print("Cadena en mayúsculas:", cadena_mayusculas)

cadena_minusculas = convertir_a_minusculas(cadena)
print("Cadena en minúsculas:", cadena_minusculas)
